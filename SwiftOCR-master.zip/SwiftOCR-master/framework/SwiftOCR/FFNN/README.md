[![Swift AI Banner](https://github.com/collinhundley/Swift-AI/blob/master/SiteAssets/Banner.png?raw=true)](https://github.com/collinhundley/Swift-AI#care-enough-to-donate)

# Source

This folder is where you'll find all of the source files for Swift AI.

For instructions and examples, see the [documentation](https://github.com/collinhundley/Swift-AI/blob/master/Documentation/README.md).
